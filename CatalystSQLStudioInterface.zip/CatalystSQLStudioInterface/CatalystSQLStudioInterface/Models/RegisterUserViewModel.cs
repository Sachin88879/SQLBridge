﻿
using System.ComponentModel.DataAnnotations;
namespace CatalystSQLStudioInterface.Models
{
    public class RegisterUserViewModel
    {
        [Required]
        public string UserName { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        [Required, MinLength(6)]
        public string Password { get; set; }

        [Required]
        public string Role { get; set; } = "Viewer"; // Default role

        public bool IsActive { get; set; } = true;
    }

}
