﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace CatalystSQLStudioInterface.Models
{
    public class SqlExecutorViewModel
    {
        [Required(ErrorMessage = "Server selection is required.")]
        public string SelectedServer { get; set; }

        [Required(ErrorMessage = "Database selection is required.")]
        public string SelectedDatabase { get; set; }
        public string SqlScript { get; set; }

        public List<SelectListItem> ServerList { get; set; } = new();
        public List<SelectListItem> DatabaseList { get; set; } = new();

        public string RequestedBy { get; set; }

        // Execution results
        public List<DataTable> ResultSets { get; set; } = new();
        public List<string> Messages { get; set; } = new();
        public int RowsAffected { get; set; }
        public int? ReturnValue { get; set; }
        public string Status { get; set; }
    }

}
