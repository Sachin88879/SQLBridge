﻿using System.Data;

namespace CatalystSQLStudioInterface.Models
{
    public class SqlExecutionResult
    {
        public List<DataTable> ResultSets { get; set; } = new();
        public List<string> Messages { get; set; } = new();
        public int RowsAffected { get; set; }
        public int? ReturnValue { get; set; }
        public string Status { get; set; }
        public string? RawOutput => string.Join("\n", Messages);
    }

}
