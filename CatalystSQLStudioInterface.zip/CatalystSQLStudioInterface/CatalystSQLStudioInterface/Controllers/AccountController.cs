﻿// Controllers/AccountController.cs
using CatalystSQLStudioInterface.Interfaces;
using CatalystSQLStudioInterface.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace CatalystSQLStudioInterface.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _userRepository;

        public AccountController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var user = _userRepository.ValidateUser(model.UserId, model.Password);
            if (user != null)
            {
                TempData["Success"] = "Login successful!";
                HttpContext.Session.SetInt32("UserId", user.UserID);
                HttpContext.Session.SetString("UserName", user.UserName);
                return RedirectToAction("Index", "SqlExecutor");
            }

            ModelState.AddModelError("", "Invalid User ID or Password");
            return View(model);
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (_userRepository.UserExists(model.UserName))
            {
                ModelState.AddModelError("", "Username already exists.");
                return View(model);
            }

            model.IsActive = true;
            var success = _userRepository.RegisterUser(model);

            if (success)
            {
                TempData["Success"] = "Registration successful! Please login.";
                return RedirectToAction("Login", "Account");
            }

            ModelState.AddModelError("", "Registration failed. Try again later.");
            return View(model);
        }
    }
}
