﻿using CatalystSQLStudioInterface.Interfaces;
using CatalystSQLStudioInterface.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CatalystSQLStudioInterface.Controllers
{
    public class SqlExecutorController : Controller
    {
        private readonly ISqlExecutorRepository _repo;

        public SqlExecutorController(ISqlExecutorRepository repo)
        {
            _repo = repo;
        }

        // GET: /SqlExecutor/
        [HttpGet]
        public IActionResult Index()
        {
            int? userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToAction("Login", "Account");

            var model = new SqlExecutorViewModel
            {
                ServerList = _repo.GetAllServers()
                                  .Select(server => new SelectListItem
                                  {
                                      Text = server,
                                      Value = server
                                  }).ToList()
            };

            return View(model);
        }

        // POST: /SqlExecutor/Execute
        //[HttpPost]
        //public IActionResult  Execute(SqlExecutorViewModel model)
        //{
        //    int? userId = HttpContext.Session.GetInt32("UserId");
        //    if (!userId.HasValue)
        //        return RedirectToAction("Login", "Account");

        //    // Reload server listssss
        //    model.ServerList = _repo.GetAllServers()
        //                            .Select(server => new SelectListItem
        //                            {
        //                                Text = server,
        //                                Value = server
        //                            }).ToList();

        //    // Reload database list if server is selected
        //    if (!string.IsNullOrWhiteSpace(model.SelectedServer))
        //    {
        //        model.DatabaseList = _repo.GetDatabasesForServer(model.SelectedServer)
        //            .Select(db => new SelectListItem
        //            {
        //                Text = db,
        //                Value = db
        //            }).ToList();
        //    }

        //    // Execute SQL and populate result
        //    var result =  _repo.ExecuteScript(
        //        model.SelectedServer,
        //        model.SelectedDatabase,
        //        model.SqlScript,
        //        userId.Value,
        //        model.RequestedBy
        //    );

        //    // Fill model with result details
        //    model.Messages = result.Messages;
        //    model.ResultSets = result.ResultSets;
        //    model.RowsAffected = result.RowsAffected;
        //    model.ReturnValue = result.ReturnValue; // Optional: only if you include it in SqlExecutionResult
        //    model.Status = result.Status;

        //    return View("Index", model);
        //}

        [HttpPost]
        public IActionResult Execute(SqlExecutorViewModel model, CancellationToken cancellationToken)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return Unauthorized(); // For AJAX calls

            // Reload server list
            model.ServerList = _repo.GetAllServers()
                .Select(server => new SelectListItem
                {
                    Text = server,
                    Value = server
                }).ToList();

            // Reload database list
            if (!string.IsNullOrWhiteSpace(model.SelectedServer))
            {
                model.DatabaseList = _repo.GetDatabasesForServer(model.SelectedServer)
                    .Select(db => new SelectListItem
                    {
                        Text = db,
                        Value = db
                    }).ToList();
            }

            try
            {
                var result = _repo.ExecuteScript(
                    model.SelectedServer,
                    model.SelectedDatabase,
                    model.SqlScript,
                    userId.Value,
                    model.RequestedBy,
                    cancellationToken // Optional depending on repo implementation
                );

                model.Messages = result.Messages;
                model.ResultSets = result.ResultSets;
                model.RowsAffected = result.RowsAffected;
                model.ReturnValue = result.ReturnValue;
                model.Status = result.Status ?? "Success";
            }
            catch (OperationCanceledException)
            {
                model.Status = "Cancelled";
                model.Messages = new List<string> { "Execution was cancelled." };
            }
            catch (Exception ex)
            {
                model.Status = "Error";
                model.Messages = new List<string> { $"❌ Error: {ex.Message}" };
            }

            return PartialView("~/Views/SqlExecutor/_Output.cshtml", model);
        }


        // GET: /SqlExecutor/GetDatabases?server=xxx
        [HttpGet]
        public JsonResult GetDatabases(string server)
        {
            if (string.IsNullOrWhiteSpace(server))
                return Json(new List<string>());

            var databases = _repo.GetDatabasesForServer(server);
            return Json(databases);
        }
    }
}
