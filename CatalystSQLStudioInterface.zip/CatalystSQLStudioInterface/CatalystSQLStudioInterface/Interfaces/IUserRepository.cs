﻿using CatalystSQLStudioInterface.Models;

namespace CatalystSQLStudioInterface.Interfaces
{
    public interface IUserRepository
    {
        User ValidateUser(string username, string password);
        bool RegisterUser(User user);
        bool UserExists(string userName);
    }
}
