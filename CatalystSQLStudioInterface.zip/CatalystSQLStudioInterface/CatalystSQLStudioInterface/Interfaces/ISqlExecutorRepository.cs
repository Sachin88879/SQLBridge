﻿using CatalystSQLStudioInterface.Models;

namespace CatalystSQLStudioInterface.Interfaces
{
    public interface ISqlExecutorRepository
    {
        public List<string> GetAllServers();

        public List<string> GetDatabasesForServer(string server);

        SqlExecutionResult ExecuteScript(
           string server,
           string database,
           string script,
           int userId,
           string requestedBy,
           CancellationToken cancellationToken = default
       );

    }

}
