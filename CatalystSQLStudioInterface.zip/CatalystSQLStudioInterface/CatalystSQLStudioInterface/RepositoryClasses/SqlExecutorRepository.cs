﻿using CatalystSQLStudioInterface.Interfaces;
using CatalystSQLStudioInterface.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace CatalystSQLStudioInterface.RepositoryClasses
{
    public class SqlExecutorRepository : ISqlExecutorRepository
    {
        private readonly string _baseConnectionString;
        private const string ConnectionName = "MainDbContext";

        public SqlExecutorRepository(IConfiguration configuration)
        {
            // Reads from appsettings.json: ConnectionStrings > MainDbContext
            _baseConnectionString = configuration.GetConnectionString(ConnectionName);
        }

        public List<string> GetAllServers()
        {
            var servers = new List<string>();
            try
            {
                using var conn = new SqlConnection(_baseConnectionString);
                conn.Open();

                using var cmd = new SqlCommand("usp_GetActiveServers", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    servers.Add(reader.GetString(0));
                }
            }
            catch (Exception ex)
            {
                // Log or handle exception
                servers.Add($"Error: {ex.Message}");
            }

            return servers;
        }

        public List<string> GetDatabasesForServer(string server)
        {
            var databases = new List<string>();

            try
            {
                // Step 1: Fetch SQL Login & Password
                string sqlLogin = null, sqlPassword = null;

                using (var lookupConn = new SqlConnection(_baseConnectionString))
                {
                    lookupConn.Open();
                    using var lookupCmd = new SqlCommand(
                        "SELECT TOP 1 SqlLogin, SqlPassword FROM RemoteDatabaseConfig WHERE ServerName = @Server", lookupConn);
                    lookupCmd.Parameters.AddWithValue("@Server", server);

                    using var reader = lookupCmd.ExecuteReader();
                    if (reader.Read())
                    {
                        sqlLogin = reader["SqlLogin"]?.ToString();
                        sqlPassword = reader["SqlPassword"]?.ToString();
                    }
                    else
                    {
                        databases.Add($"❌ Credentials not found for server: {server}");
                        return databases;
                    }
                }

                // Step 2: Build connection string to target server
                var builder = new SqlConnectionStringBuilder
                {
                    DataSource = server,
                    InitialCatalog = "master", // Default to 'master' or some known DB to run the SP
                    UserID = sqlLogin,
                    Password = sqlPassword,
                    IntegratedSecurity = false,
                    MultipleActiveResultSets = true,
                    ConnectTimeout = 10000,
                    TrustServerCertificate = true
                };

                using var remoteConn = new SqlConnection(builder.ConnectionString);
                remoteConn.Open();

                using var cmd = new SqlCommand("usp_GetDatabasesByServer", remoteConn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@ServerName", server);

                using var resultReader = cmd.ExecuteReader();
                while (resultReader.Read())
                {
                    databases.Add(resultReader.GetString(0));
                }
            }
            catch (Exception ex)
            {
                databases.Add($"❌ Error: {ex.Message}");
            }

            return databases;
        }
        //public SqlExecutionResult ExecuteScript(string server, string database, string script, int userId = 0,string RequestedBy="")
        //{
        //    var result = new SqlExecutionResult();
        //    var stopwatch = new Stopwatch();

        //    try
        //    {
        //        // Step 1: Fetch SQL Login & Password
        //        string sqlLogin = null, sqlPassword = null;

        //        using (var lookupConn = new SqlConnection(_baseConnectionString))
        //        {
        //            lookupConn.Open();
        //            using var lookupCmd = new SqlCommand(
        //                "SELECT TOP 1 SqlLogin, SqlPassword FROM RemoteDatabaseConfig WHERE ServerName = @Server", lookupConn);
        //            lookupCmd.Parameters.AddWithValue("@Server", server);

        //            using var reader = lookupCmd.ExecuteReader();
        //            if (reader.Read())
        //            {
        //                sqlLogin = reader["SqlLogin"]?.ToString();
        //                sqlPassword = reader["SqlPassword"]?.ToString();
        //            }
        //            else
        //            {
        //                result.Status = "Failed";
        //                result.Messages.Add($"❌ Credentials not found for {server}/{database}");
        //                LogExecution(userId, server, database, script, null, result.Status, null, null, RequestedBy);
        //                return result;
        //            }
        //        }

        //        // Step 2: Build connection string
        //        var builder = new SqlConnectionStringBuilder
        //        {
        //            DataSource = server,
        //            InitialCatalog = database,
        //            UserID = sqlLogin,
        //            Password = sqlPassword,
        //            IntegratedSecurity = false,
        //            MultipleActiveResultSets = true,
        //            ConnectTimeout = 10000,
        //            TrustServerCertificate = true
        //        };

        //        using var conn = new SqlConnection(builder.ConnectionString);
        //        conn.InfoMessage += (sender, e) =>
        //        {
        //            foreach (var msg in e.Message.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
        //            {
        //                result.Messages.Add($"ℹ️ {msg.Trim()}");
        //            }
        //        };
        //        conn.Open();

        //        using var cmd = new SqlCommand(script, conn)
        //        {
        //            CommandType = CommandType.Text,
        //            CommandTimeout = 36000
        //        };

        //        stopwatch.Start();

        //        using var readerResult = cmd.ExecuteReader();
        //        int totalRowsAffected = 0;
        //        bool hasResultSet = false;

        //        do
        //        {
        //            if (readerResult.HasRows)
        //            {
        //                var dt = new DataTable();

        //                // Add columns
        //                for (int i = 0; i < readerResult.FieldCount; i++)
        //                {
        //                    dt.Columns.Add(readerResult.GetName(i), readerResult.GetFieldType(i));
        //                }

        //                // Add rows
        //                while (readerResult.Read())
        //                {
        //                    var row = dt.NewRow();
        //                    for (int i = 0; i < readerResult.FieldCount; i++)
        //                    {
        //                        row[i] = readerResult.GetValue(i);
        //                    }
        //                    dt.Rows.Add(row);
        //                }

        //                result.ResultSets.Add(dt);
        //                hasResultSet = true;
        //            }
        //            else
        //            {
        //                // Still need to move the reader forward if there are no rows
        //                totalRowsAffected += readerResult.RecordsAffected;
        //                while (readerResult.Read()) { /* consume empty */ }
        //            }
        //        }
        //        while (readerResult.NextResult());

        //        stopwatch.Stop();

        //        result.RowsAffected = totalRowsAffected;
        //        var formattedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

        //        result.Messages.Add($"⏱ Execution Time: {formattedTime}");

        //        if (hasResultSet)
        //            result.Messages.Add($"✅ Query executed. {result.ResultSets.Count} result set(s) returned.");

        //        if (totalRowsAffected > 0)
        //            result.Messages.Add($"✅ {totalRowsAffected} row(s) affected.");

        //        if (!hasResultSet && totalRowsAffected == 0)
        //            result.Messages.Add($"✅ Script executed. No rows returned or affected.");

        //        result.Status = "Success";

        //        var RawOutput = result.ResultSets.Count > 0
        //            ? JsonConvert.SerializeObject(result.ResultSets[0], Formatting.Indented)
        //            : string.Join("\n", result.Messages);

        //        LogExecution(userId, server, database, script, result.RawOutput, result.Status, formattedTime, result.RowsAffected, RequestedBy);
        //    }
        //    catch (Exception ex)
        //    {
        //        stopwatch.Stop();

        //        result.Status = "Failed";
        //        result.Messages.Add($"❌ Exception: {ex.Message}");
        //        if (ex.InnerException != null)
        //            result.Messages.Add($"🔍 Inner: {ex.InnerException.Message}");

        //        string formattedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
        //        result.Messages.Add($"⏱ Execution Time: {formattedTime}");

        //        var RawOutput = string.Join("\n", result.Messages);

        //        LogExecution(userId, server, database, script, result.RawOutput, result.Status, formattedTime, null, RequestedBy);
        //    }

        //    return result;
        //}

        //public async Task<SqlExecutionResult> ExecuteScriptAsync(string server, string database, string script, int userId = 0)
        //{
        //    var result = new SqlExecutionResult();
        //    var stopwatch = Stopwatch.StartNew();

        //    if (string.IsNullOrWhiteSpace(server) || string.IsNullOrWhiteSpace(database) || string.IsNullOrWhiteSpace(script))
        //    {
        //        result.Status = "Failed";
        //        result.Messages.Add("❌ Invalid input parameters.");
        //        await LogExecutionAsync(userId, server, database, script, string.Join("\n", result.Messages), result.Status, null, null);
        //        return result;
        //    }

        //    try
        //    {
        //        var (login, password) = await GetCredentialsAsync(server, result, userId, script);
        //        if (login == null) return result;

        //        var connectionString = new SqlConnectionStringBuilder
        //        {
        //            DataSource = server,
        //            InitialCatalog = database,
        //            UserID = login,
        //            Password = password,
        //            IntegratedSecurity = false,
        //            ConnectTimeout = 30,
        //            TrustServerCertificate = true
        //        }.ConnectionString;

        //        using var conn = new SqlConnection(connectionString);
        //        conn.InfoMessage += (_, e) =>
        //        {
        //            foreach (var msg in e.Message.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        //                result.Messages.Add($"ℹ️ {msg.Trim()}");
        //        };

        //        await conn.OpenAsync();

        //        using var cmd = new SqlCommand(script, conn)
        //        {
        //            CommandType = CommandType.Text,
        //            CommandTimeout = 1000
        //        };

        //        using var reader = await cmd.ExecuteReaderAsync();
        //        var resultSets = new List<DataTable>();
        //        int resultSetIndex = 0;

        //        do
        //        {
        //            // Try loading result set if available
        //            if (!reader.HasRows && reader.FieldCount == 0)
        //                continue; // Move on if no rows/columns

        //            var dt = new DataTable();
        //            try
        //            {
        //                dt.Load(reader);
        //                resultSets.Add(dt);
        //                result.Messages.Add($"✅ Result set #{++resultSetIndex} returned with {dt.Rows.Count} row(s).");
        //            }
        //            catch (Exception ex)
        //            {
        //                result.Messages.Add($"⚠️ Error loading result set #{resultSetIndex + 1}: {ex.Message}");
        //            }

        //        } while (await reader.NextResultAsync());

        //        int totalAffectedRows = reader.RecordsAffected;
        //        result.RowsAffected = totalAffectedRows;
        //        result.ResultSets = resultSets;

        //        if (!resultSets.Any() && totalAffectedRows > 0)
        //            result.Messages.Add($"✅ {totalAffectedRows} row(s) affected.");

        //        if (!resultSets.Any() && totalAffectedRows == 0)
        //            result.Messages.Add("✅ Script executed. No result sets or rows affected.");

        //        result.Status = "Success";
        //        var time = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
        //        result.Messages.Add($"⏱ Execution Time: {time}");

        //        var rawOutput = resultSets.Any()
        //            ? JsonConvert.SerializeObject(resultSets, Formatting.Indented)
        //            : string.Join("\n", result.Messages);

        //        await LogExecutionAsync(userId, server, database, script, rawOutput, result.Status, time, result.RowsAffected);
        //    }
        //    catch (SqlException ex) when (ex.Number == -2)
        //    {
        //        result.Status = "Timeout";
        //        result.Messages.Add("⏱ SQL command timed out.");
        //        result.Messages.Add($"❌ Exception: {ex.Message}");

        //        var rawOutput = string.Join("\n", result.Messages);
        //        await LogExecutionAsync(userId, server, database, script, rawOutput, result.Status, null, null);
        //    }
        //    catch (Exception ex)
        //    {
        //        result.Status = "Failed";
        //        result.Messages.Add($"❌ Exception: {ex.Message}");
        //        if (ex.InnerException != null)
        //            result.Messages.Add($"🔍 Inner: {ex.InnerException.Message}");

        //        var time = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
        //        result.Messages.Add($"⏱ Execution Time: {time}");

        //        var rawOutput = string.Join("\n", result.Messages);
        //        await LogExecutionAsync(userId, server, database, script, rawOutput, result.Status, time, null);
        //    }
        //    finally
        //    {
        //        stopwatch.Stop();
        //    }

        //    return result;
        //}

        public SqlExecutionResult ExecuteScript(
            string server,
            string database,
            string script,
            int userId = 0,
            string requestedBy = "",
            CancellationToken cancellationToken = default
        )
        {
            var result = new SqlExecutionResult();
            var stopwatch = new Stopwatch();

            try
            {
                // Step 1: Fetch SQL Login & Password
                string sqlLogin = null, sqlPassword = null;

                using (var lookupConn = new SqlConnection(_baseConnectionString))
                {
                    lookupConn.Open();
                    using var lookupCmd = new SqlCommand(
                        "SELECT TOP 1 SqlLogin, SqlPassword FROM RemoteDatabaseConfig WHERE ServerName = @Server", lookupConn);
                    lookupCmd.Parameters.AddWithValue("@Server", server);

                    using var reader = lookupCmd.ExecuteReader();
                    if (reader.Read())
                    {
                        sqlLogin = reader["SqlLogin"]?.ToString();
                        sqlPassword = reader["SqlPassword"]?.ToString();
                    }
                    else
                    {
                        result.Status = "Failed";
                        result.Messages.Add($"❌ Credentials not found for {server}/{database}");
                        LogExecution(userId, server, database, script, null, result.Status, null, null, requestedBy);
                        return result;
                    }
                }

                // Step 2: Build connection string
                var builder = new SqlConnectionStringBuilder
                {
                    DataSource = server,
                    InitialCatalog = database,
                    UserID = sqlLogin,
                    Password = sqlPassword,
                    IntegratedSecurity = false,
                    MultipleActiveResultSets = true,
                    ConnectTimeout = 30,
                    TrustServerCertificate = true
                };

                using var conn = new SqlConnection(builder.ConnectionString);
                conn.InfoMessage += (sender, e) =>
                {
                    foreach (var msg in e.Message.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        result.Messages.Add($"ℹ️ {msg.Trim()}");
                    }
                };

                conn.Open();

                using var cmd = new SqlCommand(script, conn)
                {
                    CommandType = CommandType.Text,
                    CommandTimeout = 3600
                };

                stopwatch.Start();

                using var readerResult = cmd.ExecuteReader();
                int totalRowsAffected = 0;
                bool hasResultSet = false;

                do
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    if (readerResult.HasRows)
                    {
                        var dt = new DataTable();

                        for (int i = 0; i < readerResult.FieldCount; i++)
                        {
                            dt.Columns.Add(readerResult.GetName(i), readerResult.GetFieldType(i));
                        }

                        while (readerResult.Read())
                        {
                            cancellationToken.ThrowIfCancellationRequested();

                            var row = dt.NewRow();
                            for (int i = 0; i < readerResult.FieldCount; i++)
                            {
                                row[i] = readerResult.GetValue(i);
                            }
                            dt.Rows.Add(row);
                        }

                        result.ResultSets.Add(dt);
                        hasResultSet = true;
                    }
                    else
                    {
                        totalRowsAffected += readerResult.RecordsAffected;
                        while (readerResult.Read()) { /* consume */ }
                    }
                }
                while (readerResult.NextResult());

                stopwatch.Stop();

                result.RowsAffected = totalRowsAffected;
                string formattedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                result.Messages.Add($"⏱ Execution Time: {formattedTime}");

                if (hasResultSet)
                    result.Messages.Add($"✅ Query executed. {result.ResultSets.Count} result set(s) returned.");

                if (totalRowsAffected > 0)
                    result.Messages.Add($"✅ {totalRowsAffected} row(s) affected.");

                if (!hasResultSet && totalRowsAffected == 0)
                    result.Messages.Add($"✅ Script executed. No rows returned or affected.");

                result.Status = "Success";

                var RawOutput = result.ResultSets.Count > 0
                    ? JsonConvert.SerializeObject(result.ResultSets[0], Formatting.Indented)
                    : string.Join("\n", result.Messages);

                LogExecution(userId, server, database, script, result.RawOutput, result.Status, formattedTime, result.RowsAffected, requestedBy);
            }
            catch (OperationCanceledException)
            {
                stopwatch.Stop();
                result.Status = "Cancelled";
                result.Messages.Add("⚠️ Execution was cancelled.");
                result.Messages.Add($"⏱ Elapsed before cancel: {stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff")}");
                var RawOutput = string.Join("\n", result.Messages);

                LogExecution(userId, server, database, script, result.RawOutput, result.Status, stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff"), null, requestedBy);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                result.Status = "Failed";
                result.Messages.Add($"❌ Exception: {ex.Message}");
                if (ex.InnerException != null)
                    result.Messages.Add($"🔍 Inner: {ex.InnerException.Message}");

                result.Messages.Add($"⏱ Execution Time: {stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff")}");
                var RawOutput = string.Join("\n", result.Messages);

                LogExecution(userId, server, database, script, result.RawOutput, result.Status, stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff"), null, requestedBy);
            }

            return result;
        }

        private async Task<(string login, string password)> GetCredentialsAsync(string server, SqlExecutionResult result, int userId, string script)
        {
            using var conn = new SqlConnection(_baseConnectionString);
            await conn.OpenAsync();

            using var cmd = new SqlCommand("SELECT TOP 1 SqlLogin, SqlPassword FROM RemoteDatabaseConfig WHERE ServerName = @Server", conn);
            cmd.Parameters.AddWithValue("@Server", server);

            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return (
                    reader["SqlLogin"]?.ToString(),
                    reader["SqlPassword"]?.ToString()
                );
            }

            result.Status = "Failed";
            result.Messages.Add($"❌ Credentials not found for server: {server}");
            await LogExecution(userId, server, null, script, null, result.Status, null, null,"");
            return (null, null);
        }
        private async Task LogExecution(int userId,string server,string database,string script,string rawOutput,string status,string executionTime,int? rowsAffected, string? Remarks)
        {
            try
            {
                using var conn = new SqlConnection(_baseConnectionString);
                await conn.OpenAsync();

                using var cmd = new SqlCommand(@"
            INSERT INTO ScriptExecutionLogs
                (UserID, ServerName, DatabaseName, ScriptText, ExecutionResult, Status, ResultSet, AffectedRows,Remarks)
            VALUES
                (@UserID, @ServerName, @DatabaseName, @ScriptText, @ExecutionResult, @Status, @ResultSet, @AffectedRows,@Remarks)", conn);

                cmd.Parameters.AddWithValue("@UserID", userId);
                cmd.Parameters.AddWithValue("@ServerName", server ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DatabaseName", database ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ScriptText", script ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ExecutionResult", rawOutput ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Status", status ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ResultSet", rawOutput ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Remarks", Remarks ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@AffectedRows", rowsAffected.HasValue ? rowsAffected.Value : (object)DBNull.Value);

                await cmd.ExecuteNonQueryAsync();
            }
            catch
            {
                // Optional fallback: write to file or event log
            }
        }

    }
}
