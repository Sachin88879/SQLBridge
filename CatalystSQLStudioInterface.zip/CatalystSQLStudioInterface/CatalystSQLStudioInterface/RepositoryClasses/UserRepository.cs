﻿using CatalystSQLStudioInterface.Interfaces;
using CatalystSQLStudioInterface.Models;
using CatalystSQLStudioInterface.Helpers;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CatalystSQLStudioInterface.RepositoryClasses
{
    public class UserRepository : IUserRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<UserRepository> _logger;

        public UserRepository(IConfiguration configuration, ILogger<UserRepository> logger)
        {
            _connectionString = configuration.GetConnectionString("MainDbContext");
            _logger = logger;
        }

        public User ValidateUser(string username, string password)
        {
            try
            {
                using var conn = new SqlConnection(_connectionString);
                conn.Open();

                var query = "SELECT TOP 1 * FROM Users WHERE UserName = @UserName AND IsActive = 1";
                using var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserName", username);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    var user = new User
                    {
                        UserID = Convert.ToInt32(reader["UserID"]),
                        UserName = reader["UserName"].ToString(),
                        Email = reader["Email"]?.ToString(),
                        PasswordHash = reader["PasswordHash"]?.ToString(),
                        Role = reader["Role"]?.ToString(),
                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };
                    return PasswordHelper.VerifyPassword(password, user.PasswordHash) ? user : null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating user");
            }
            return null;
        }

        public bool RegisterUser(User user)
        {
            //try
            //{
            //    using var conn = new SqlConnection(_connectionString);
            //    using var cmd = new SqlCommand(@"
            //        INSERT INTO dbo.Users (UserName, Email, PasswordHash, Role, IsActive)
            //        VALUES (@UserName, @Email, @PasswordHash, @Role, @IsActive)", conn);

            //    cmd.Parameters.AddWithValue("@UserName", user.UserName);
            //    cmd.Parameters.AddWithValue("@Email", (object)user.Email ?? DBNull.Value);
            //    cmd.Parameters.AddWithValue("@PasswordHash", PasswordHelper.HashPassword(user.PasswordHash));
            //    cmd.Parameters.AddWithValue("@Role", (object)user.Role ?? DBNull.Value);
            //    cmd.Parameters.AddWithValue("@IsActive", user.IsActive);

            //    conn.Open();
            //    return cmd.ExecuteNonQuery() > 0;
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogError(ex, "Error registering user");
            //    return false;
            //}
            return true;
        }

        public bool UserExists(string userName)
        {
            try
            {
                using var conn = new SqlConnection(_connectionString);
                using var cmd = new SqlCommand("SELECT COUNT(1) FROM dbo.Users WHERE UserName = @UserName", conn);
                cmd.Parameters.AddWithValue("@UserName", userName);

                conn.Open();
                return (int)cmd.ExecuteScalar() > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking if user exists");
                return false;
            }
        }
    }
}