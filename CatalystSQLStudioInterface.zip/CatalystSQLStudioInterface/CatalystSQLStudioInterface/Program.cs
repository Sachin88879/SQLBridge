using CatalystSQLStudioInterface.Interfaces;
using CatalystSQLStudioInterface.RepositoryClasses;
using Microsoft.Data.SqlClient;
using System.Data;

var builder = WebApplication.CreateBuilder(args);

// Get connection string from configuration
var connectionString = builder.Configuration.GetConnectionString("MainDbContext");

// ? Register services BEFORE calling builder.Build()
builder.Services.AddControllersWithViews();
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

// Register your repositories
builder.Services.AddScoped<ISqlExecutorRepository, SqlExecutorRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();

// Register ADO.NET connection using the connection string
builder.Services.AddSingleton<IDbConnection>(sp => new SqlConnection(connectionString));

var app = builder.Build();

// ? Middleware pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();          // <-- must be before UseAuthorization if you use session
app.UseAuthorization();

// Map default route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();
